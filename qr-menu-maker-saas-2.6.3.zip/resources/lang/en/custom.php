<?php

return array (
  'customer_phone_number' => 'Customer phone number',
);
